package com.example.labmanager;

import com.example.labmanager.EasterEggService.LocalBinder;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class LabStatusActivity extends Activity{
	

	LinearLayout linear;
	
	EasterEggService mService;
	boolean mBound = false;
	
	final String EasterEgg[];
	
	{
		EasterEgg = new String[3];
		EasterEgg[0] = "Lab Manager Application!";
		EasterEgg[1] = "Embedded System Software";
		EasterEgg[2] = "Made by MinSuc Kang & Keonhyuk Lee";
	}
	
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_labstatus);
		linear = (LinearLayout)findViewById(R.id.container);
		
		
		
		Button as714Btn = (Button)findViewById(R.id.AS714);
		Button r912Btn = (Button)findViewById(R.id.R912);
		Button r914Btn = (Button)findViewById(R.id.R914);
		Button easterEggBtn = (Button)findViewById(R.id.easterEggBtn);
		
		easterEggBtn.setBackgroundColor(Color.WHITE);
				
		as714Btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// AS 714 environment. read from arduino.
				Intent intent = new Intent(LabStatusActivity.this,AS714Activity.class);
				startActivity(intent);
			}
		});
		
		r912Btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//
				
			}
		});
		
	
		
		r914Btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//
				
			}
			
		});
		
		easterEggBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				//
				if(mBound){
					int num = mService.getRandomNumber();
					
					if(num != -1)
						Toast.makeText(getApplicationContext(), EasterEgg[num], Toast.LENGTH_SHORT).show();
				}
			}
		});
		
	}
	
	@Override
	protected void onStart(){
		super.onStart();
		Intent intent = new Intent(this,EasterEggService.class);
		bindService(intent,mConnection,Context.BIND_AUTO_CREATE);
	}
	
	@Override
	protected void onStop(){
		super.onStop();
		if(mBound){
			unbindService(mConnection);
			mBound = false;
		}
	}
	
	private ServiceConnection mConnection = new ServiceConnection() {
		
		@Override
		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			mBound = false;
		}
		
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			LocalBinder binder = (LocalBinder)service;
			mService = binder.getService();
			mBound = true;
		}
	};
	
	public void onBackPressed() {	// When Back key pressed, parsing stop and go to MainActivity.
		
		finish();			// this Activity end.
		
		super.onBackPressed();
	}
}
