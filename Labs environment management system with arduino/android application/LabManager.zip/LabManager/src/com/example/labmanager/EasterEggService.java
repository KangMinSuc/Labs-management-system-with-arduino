package com.example.labmanager;

import java.util.Random;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;




public class EasterEggService extends Service {

	NotificationManager mNM;
	
	int count = 0;	
	
	

	private final IBinder mBinder = new LocalBinder();
	private final Random mGenerator = new Random();
	
	public class LocalBinder extends Binder{
		EasterEggService getService(){
			return EasterEggService.this;
		}
	}


	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		count = 0;
		return mBinder;
	}

	public int getRandomNumber(){
		count++;
		if(count == 5){
			count = 0;
			return mGenerator.nextInt(3);
			
		}
		return -1;
	}
	
}
