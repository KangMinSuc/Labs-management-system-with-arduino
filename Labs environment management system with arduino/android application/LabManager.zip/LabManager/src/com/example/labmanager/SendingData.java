package com.example.labmanager;

public class SendingData {

	native void SendTemperature(int temperature);
	native void SendData(int data, int mode);
	

}
