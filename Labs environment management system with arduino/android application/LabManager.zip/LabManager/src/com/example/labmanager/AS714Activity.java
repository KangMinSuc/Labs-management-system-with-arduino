package com.example.labmanager;

import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class AS714Activity extends Activity{

	private final boolean D = false;

	LinearLayout linear;
	TextView roomText;
	TextView temperatureText, humidityText;
	TextView reservedStartText, reservedEndText;
	Button timeSendBtn;
	Spinner spinner;
	Spinner timeHourSpinner;
	Spinner timeMinSpinner;

	int hour = 0, min = 0;
	int mode = 3, data = 0;
	int time;

	int timeSendMode = 0;
	ArrayList timeHourArraylist;
	ArrayList timeMinArraylist;

	ArrayAdapter<String> timeHourAdapter;
	ArrayAdapter<String> timeMinAdapter;

	ArrayList temperatureIntegerArraylist;
	ArrayList temperatureFractionArraylist;

	ArrayAdapter<String> TemperatureIntegerAdapter;
	ArrayAdapter<String> temperatureFractionAdapter;

	static int idealTemperature = 2600;
	int fanRunning = 3;

	static int reservedStart = -1;
	static int reservedEnd = -1;

	boolean first = false;

	SendingData sendingData = new SendingData();

	ReceivingThread mThread;

	Handler mHandler = new Handler(){
		public void handleMessage(Message msg){
			if(msg.what == 0){
				temperatureText.setText("Temperature : " + msg.arg1/100 + "." + msg.arg1%100);
				humidityText.setText("Humidity : " + msg.arg2 + "%");
				//temperatureText.setText("Temperature : " + msg.arg1 + "." + msg.arg2);

				if(ButtonReceivingThread.isAutoMode){
					first = false;
					if(msg.arg1 - idealTemperature >= 150){
						try {
							if(fanRunning != 2){
								MainActivity.getOutputdataStream().write(2);
								fanRunning = 2;
								if(D) Log.e("what?","2");
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if(idealTemperature - msg.arg1 >= 150){
						try {
							if(fanRunning != 1){
								MainActivity.getOutputdataStream().write(1);
								fanRunning = 1;
								if(D) Log.e("what?","1");
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else{
						try {
							if(fanRunning != 3){
								MainActivity.getOutputdataStream().write(3);
								fanRunning = 3;
								if(D) Log.e("what?","3");
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				else{
					try {
						if(fanRunning != 3 && !first){
							MainActivity.getOutputdataStream().write(3);
							fanRunning = 3;
							if(D) Log.e("what?","4");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					first = true;
				}
			}
			else if(msg.what == 1){
				time = msg.arg1;
				Log.e("time",""+time);
				if(!ButtonReceivingThread.isAutoMode){
					if(time == reservedStart){
						try {
							MainActivity.getOutputdataStream().write(2);
							fanRunning = 2;
							ButtonReceivingThread.fanRunning = 2;
							if(D) Log.e("what?!?!?!","2");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					if(time == reservedEnd){
						try {
							MainActivity.getOutputdataStream().write(3);
							fanRunning = 3;
							ButtonReceivingThread.fanRunning = 3;
							if(D) Log.e("what?!!!!!","3");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

			}
		}
	};

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_as714);
		linear = (LinearLayout)findViewById(R.id.container);

		roomText = (TextView)findViewById(R.id.roomText);
		
		timeSendBtn = (Button)findViewById(R.id.timeSendBtn);
		temperatureText = (TextView)findViewById(R.id.temperatureText);
		humidityText = (TextView)findViewById(R.id.humidityText);
		reservedStartText = (TextView)findViewById(R.id.reservedStartText);
		reservedEndText =  (TextView)findViewById(R.id.reservedEndText);

		if(reservedStart == -1)
			reservedStartText.setText("예약 시작시간 : None");
		else
			reservedStartText.setText("예약 시작시간 : " + reservedStart/100 + ":" + reservedStart%100/10 + reservedStart%10);
		
		if(reservedEnd == -1)
			reservedEndText.setText("예약 종료시간 : None");
		else
			reservedEndText.setText("예약 종료시간 : " + reservedEnd/100 + ":" + reservedEnd%100);
		
		roomText.setText("AS714");
		roomText.setTextColor(Color.BLUE);

		mThread = new ReceivingThread(mHandler);
		mThread.setDaemon(true);

		mThread.start();

		//int mode = 3;	
		//int data = 0;
		sendingData.SendData(idealTemperature, mode);

		ButtonReceivingThread.isAutoMode = true;
		ButtonReceivingThread.isDoing = true;

		timeSendBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//int data, mode;

				/*String s = timeText.getText().toString();
				if(s == "")
					data = 0;
				else
					data = Integer.parseInt(s);
				 */

				data = hour * 100 + min;
				mode = timeSendMode + 1;

				if(mode == 1){
					reservedStart = data;
					reservedStartText.setText("예약 시작시간 : " + reservedStart/100 + ":" + reservedStart%100/10 + reservedStart%10);
				}
				else if(mode == 2){
					reservedEnd = data;
					reservedEndText.setText("예약 종료시간 : " + reservedEnd/100 + ":" + reservedEnd%100/10 + reservedEnd%10);
				}
				else if(mode == 3)
					idealTemperature = data;


				sendingData.SendData(data, mode);


			}
		});

		ArrayList timeModeArraylist = new ArrayList<String>();
		timeModeArraylist.add("시작시간 예약");
		timeModeArraylist.add("종료시간 예약");
		timeModeArraylist.add("희망온도 설정");
		ArrayAdapter<String> timeModeAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_spinner_dropdown_item, timeModeArraylist);

		spinner = (Spinner)findViewById(R.id.timeModeSpn);
		spinner.setPrompt("Select Time Mode"); 
		spinner.setAdapter(timeModeAdapter);
		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				timeSendMode = position;
				if(timeSendMode != 2){

					timeHourSpinner.setPrompt("Select Hour"); 
					timeHourSpinner.setAdapter(timeHourAdapter);
					timeHourSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

						@Override
						public void onItemSelected(AdapterView<?> parent, View view,
								int position, long id) {
							// TODO Auto-generated method stub
							hour = position;

						}

						@Override
						public void onNothingSelected(AdapterView<?> parent) {
							// TODO Auto-generated method stub
							hour = 0;
						}

					});

					timeMinSpinner.setPrompt("Select Time Min"); 
					timeMinSpinner.setAdapter(timeMinAdapter);
					timeMinSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

						@Override
						public void onItemSelected(AdapterView<?> parent, View view,
								int position, long id) {
							// TODO Auto-generated method stub
							min = position;

						}

						@Override
						public void onNothingSelected(AdapterView<?> parent) {
							// TODO Auto-generated method stub
							min = 0;
						}

					}); 
				}
				else{

					timeHourSpinner.setPrompt("Select Integer part"); 
					timeHourSpinner.setAdapter(TemperatureIntegerAdapter);
					timeHourSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

						@Override
						public void onItemSelected(AdapterView<?> parent, View view,
								int position, long id) {
							// TODO Auto-generated method stub
							hour = position + 16;

						}

						@Override
						public void onNothingSelected(AdapterView<?> parent) {
							// TODO Auto-generated method stub
							hour = 0;
						}

					}); 

					timeMinSpinner.setPrompt("Select Temperature fraction part"); 
					timeMinSpinner.setAdapter(temperatureFractionAdapter);
					timeMinSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

						@Override
						public void onItemSelected(AdapterView<?> parent, View view,
								int position, long id) {
							// TODO Auto-generated method stub
							min = position * 5;

						}

						@Override
						public void onNothingSelected(AdapterView<?> parent) {
							// TODO Auto-generated method stub
							min = 0;
						}

					}); 
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				timeSendMode = 0;
			}

		}); 

		// hour, min
		timeHourArraylist = new ArrayList<String>();
		for(int i=0;i<24;i++)
			timeHourArraylist.add(i + "시");
		timeHourAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_spinner_dropdown_item, timeHourArraylist);

		timeHourSpinner = (Spinner)findViewById(R.id.timeHourSpn);
		timeHourSpinner.setPrompt("Select Hour"); 
		timeHourSpinner.setAdapter(timeHourAdapter);
		timeHourSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				hour = position;

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				hour = 0;
			}

		}); 

		timeMinArraylist = new ArrayList<String>();
		for(int i=0;i<60;i++)
			timeMinArraylist.add(i + "분");
		timeMinAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_spinner_dropdown_item, timeMinArraylist);

		timeMinSpinner = (Spinner)findViewById(R.id.timeMinSpn);
		timeMinSpinner.setPrompt("Select Time Min");
		timeMinSpinner.setAdapter(timeMinAdapter);
		timeMinSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				min = position;

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				min = 0;
			}

		}); 
		//

		temperatureIntegerArraylist = new ArrayList<String>();
		for(int i=16;i<33;i++)
			temperatureIntegerArraylist.add(i);
		TemperatureIntegerAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_spinner_dropdown_item, temperatureIntegerArraylist);

		temperatureFractionArraylist = new ArrayList<String>();
		for(int i=0;i<100;i+=5)
			temperatureFractionArraylist.add("." + i + " C");
		temperatureFractionAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_spinner_dropdown_item, temperatureFractionArraylist);



	}

	public void onBackPressed() {	// When Back key pressed, parsing stop and go to MainActivity.


		mThread.isRunning = false;
		mThread.interrupt();

		try {

			if(MainActivity.getIsConnected())
				MainActivity.getOutputdataStream().write(3);

			if(D) Log.e("what?","3");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int mode = 7;
		int data = 0;
		sendingData.SendData(data, mode);
		ButtonReceivingThread.isDoing = false;
		ButtonReceivingThread.isAutoMode = true;
		ButtonReceivingThread.fanRunning = 3;



		finish();			// this Activity end.

		super.onBackPressed();
	}
}


