package com.example.labmanager;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.os.Handler;
import android.os.Message;

public class ReceivingThread extends Thread{

	Handler mHandler;

	int input;
	int temperature;
	int humidity;
	int time;

	int prevInput = 0;
	int prevHumidity = 0;
	int prevTemperature = 0;
	int prevTime = -1;
	
	int mode = 0;

	boolean isRunning = false;


	public ReceivingThread(Handler mHandler){
		this.mHandler = mHandler;
	}



	public void run(){

		Message msg;

		SendingData jni = new SendingData();

		isRunning = true;
		
		try {
			if(MainActivity.getIsConnected()){
				while(MainActivity.getInputdataStream().available() != 0)
					MainActivity.getInputdataStream().read();
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		while(isRunning){
			try {
				if(MainActivity.getIsConnected()){
					
					input = MainActivity.getInputdataStream().read();

					if(input == 0){
						mode = input;
						continue;
					}
					else if(input == 1){
						mode = input;
						continue;

					}

					

					//temperature = input % 128;
					//humidity = input / 128;
					if(mode == 0){
						double ddata = (double)500 * input / 1024;
						temperature = (int)(ddata*100);
						continue;
					}
					else if(mode == 1){
						humidity = input;

					}

					msg = Message.obtain();
					msg.what = 0;

					msg.arg1 = temperature;
					msg.arg2 = humidity;


					mHandler.sendMessage(msg);


					//if(prevTemperature != temperature){
					jni.SendTemperature(temperature);
//					prevTemperature = temperature;
					//}

					
					if(prevHumidity != humidity){
						int mode = 5;
						jni.SendData(humidity, mode);
						prevHumidity = humidity;
					}

					
					long now = System.currentTimeMillis();
					Date date = new Date(now);

					SimpleDateFormat CurTimeFormat = new SimpleDateFormat("HHmm");

					// 지정된 포맷으로 String 타입 리턴 

					String strCurTime = CurTimeFormat.format(date);
					
					prevTime = time;
					time = Integer.parseInt(strCurTime);
					
					if(prevTime != time){
						msg = Message.obtain();
						msg.what = 1;
						msg.arg1 = time;
						mHandler.sendMessage(msg);
						
						int mode = 6;
						jni.SendData(time, mode);
					}
					
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}
}
