package com.example.labmanager;

import java.io.IOException;

import android.util.Log;


public class ButtonReceivingThread extends Thread {

	native int buttonInput();
	public static boolean isWorking = false;
	public static boolean isAutoMode = true;
	public static boolean isDoing = false;
	public static int fanRunning = 3;
	
	private final boolean D = true;
	//Handler mHandler;

	SendingData jni = new SendingData();

	public void run(){

		isWorking = true;

		while(isWorking){
			int button = buttonInput();

			int mode = 4;

			if(D) Log.d("button",button + " clicked!");

			if(isDoing)
				jni.SendData(button, mode);

			if(button == 0){
				isAutoMode = !isAutoMode;
			}

			if(!isAutoMode && MainActivity.getIsConnected() && isDoing){
				if(button == 1){
					try {
						if(fanRunning != 2){
							MainActivity.getOutputdataStream().write(2);
							fanRunning = 2;
							if(D) Log.e("what?","2");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(button == 2){
					try {
						if(fanRunning != 1){
							MainActivity.getOutputdataStream().write(1);
							fanRunning = 1;
							if(D) Log.e("what?","1");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(button == 4){

					try {
						if(fanRunning != 3){
							MainActivity.getOutputdataStream().write(3);
							fanRunning = 3;
							if(D) Log.e("what?","3");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}


			}



		}
	}
}
