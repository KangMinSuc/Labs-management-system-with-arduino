package com.example.labmanager;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends Activity{


	LinearLayout linear;
	ButtonReceivingThread mThread;
	
	TextView bluetoothStatusText;

	// Debugging
	private static final String TAG = "Bluetooth";
	private static final boolean D = true;

	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;
	private BluetoothAdapter bluetoothAdapter = null;

	//
	public static BluetoothAdapter localAdapter;
	public static BluetoothSocket socketHC06;
	boolean success=false;
	private static OutputStream mmOutputStream;
	private static InputStream	mmInputStream;
	private static DataInputStream inputdataStream;
	private static DataOutputStream outputdataStream;
	private static boolean isConnected = false;

	private static final UUID MY_UUID =
			UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); 

	private static String HC06Address = "98:D3:31:40:2F:54";
	//		private static String HC06Address = "00:13:04:03:03:74";	// Lighter

	

	public static DataOutputStream getOutputdataStream(){
		return outputdataStream;
	}

	public static DataInputStream getInputdataStream(){
		return inputdataStream;
	}

	public static boolean getIsConnected(){
		return isConnected;
	}

	//Enables Bluetooth if not enabled
	public void enableBT(){
		localAdapter=BluetoothAdapter.getDefaultAdapter();
		//If Bluetooth not enable then do it
		if(localAdapter.isEnabled()==false){
			localAdapter.enable();
			while(!(localAdapter.isEnabled())){
			}
		}
	}

	//connect to arduino
	public boolean connectToHC06(){
		//get the BluetoothDevice of the arduino
		BluetoothDevice hc06Device = localAdapter.getRemoteDevice(HC06Address);

		//try to connect to the arduino
		try {

			socketHC06 = hc06Device.createRfcommSocketToServiceRecord(UUID
					.fromString("00001101-0000-1000-8000-00805F9B34FB"));

			socketHC06.connect();


			mmOutputStream = socketHC06.getOutputStream();
			mmInputStream = socketHC06.getInputStream();
			inputdataStream = new DataInputStream(mmInputStream);
			outputdataStream = new DataOutputStream(mmOutputStream);
			success = true;

		} catch (IOException e) {
			if(D) Log.d("Bluetooth","Err: Device not found or cannot connect");
			success=false;
		}
		if(D) if(success) Log.d("Bluetooth","Connected!!");
		return success;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		linear = (LinearLayout)findViewById(R.id.container);

		// each button for each menu.
		Button bluetoothBtn = (Button)findViewById(R.id.bluetoothBtn);
		Button roomStatusBtn = (Button)findViewById(R.id.statusBtn);
		//Button puzzleBtn = (Button)findViewById(R.id.puzzleBtn);
		
		bluetoothStatusText = (TextView)findViewById(R.id.bluetoothStatusText);
		
		bluetoothStatusText.setText("Bluetooth Unconnected...");
		bluetoothStatusText.setTextColor(Color.RED);
		
		
		System.loadLibrary("labmanager");

		// Get local Bluetooth adapter
		bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		// If the adapter is null, then Bluetooth is not supported
		if (bluetoothAdapter == null) {
			Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
			finish();
			return;
		}

		mThread = new ButtonReceivingThread();
		mThread.setDaemon(true);
		mThread.start();

		bluetoothBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// go to bluetooth activity.
				//Intent intent = new Intent(MainActivity.this,MainActivity.class);
				//startActivity(intent);
				if(D) Log.e(TAG, "++ ON START ++");
				// If BT is not on, request that it be enabled.
				if (!bluetoothAdapter.isEnabled()) {
					Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
					startActivityForResult(enableIntent, REQUEST_ENABLE_BT);

				} 
				else {
					try{
						enableBT();

						if(connectToHC06()){
							isConnected = true;
							bluetoothStatusText.setText("Bluetooth Connected!");
							bluetoothStatusText.setTextColor(Color.BLUE);

						}

					}
					catch(Exception e){
						e.printStackTrace();
					}

				}
			}

		});

		roomStatusBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// go to parsing activity.
				Intent intent = new Intent(MainActivity.this,LabStatusActivity.class);
				startActivity(intent);
			}

		});

		/*puzzleBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// go to puzzle activity.
				//Intent intent = new Intent(MainActivity.this,PuzzleActivity.class);
				//startActivity(intent);
			}

		});*/

	}

	public void onBackPressed() {		// End program.

		if(MainActivity.getIsConnected()){
			try {
				MainActivity.getOutputdataStream().write(3);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		moveTaskToBack(true); 

		finish();		// this Activity end.
		android.os.Process.killProcess(android.os.Process.myPid());	// kill process to end program.
	}





}
