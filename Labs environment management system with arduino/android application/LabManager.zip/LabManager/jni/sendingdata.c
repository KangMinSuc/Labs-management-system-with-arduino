#include "jni.h"
#include "android/log.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define LOG_TAG "MyTag"
//#define LOGV(...)   __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__)

#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__) 

#define DEVICE_DRIVER_NAME "/dev/driver"

JNIEXPORT void JNICALL Java_com_example_labmanager_SendingData_SendTemperature
  (JNIEnv *env, jobject obj, jint data){
	int dev;
	
	//LOGV("native data %d \n",data);

	//printf("1\n");
	dev = open(DEVICE_DRIVER_NAME, O_RDWR);

	if(dev < 0){
		printf("Device open error : %s\n",DEVICE_DRIVER_NAME);
		return ;
	}

	write(dev,&data,sizeof(data));

	close(dev);


  }

JNIEXPORT void JNICALL Java_com_example_labmanager_SendingData_SendData
  (JNIEnv *env, jobject obj, jint data, jint mode){
	int dev;
	
	//LOGV("native data %d \n",data);

	data |= (mode << 16);

	
	//LOGV("sending data %d \n",data);
	
	//printf("1\n");
	dev = open(DEVICE_DRIVER_NAME, O_RDWR);

	if(dev < 0){
		printf("Device open error : %s\n",DEVICE_DRIVER_NAME);
		return ;
	}

	write(dev,&data,sizeof(data));

	close(dev);


  }

