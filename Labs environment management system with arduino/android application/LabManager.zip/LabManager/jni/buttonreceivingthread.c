#include "jni.h"
#include "android/log.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#define LOG_TAG "MyTag"
//#define LOGV(...)   __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__)

#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__) 

#define MAX_BUTTON 9
#define DEVICE_DRIVER_NAME "/dev/fpga_push_switch"

JNIEXPORT jint JNICALL Java_com_example_labmanager_ButtonReceivingThread_buttonInput
(JNIEnv *env, jobject obj){
	int dev;
	int buff_size;
	jint i;
	int changed = -1;

	unsigned char push_sw_buff[MAX_BUTTON] = {0, };
	unsigned char pushed_sw_buff[MAX_BUTTON] = {0, };




	// fpga switch open.
	dev = open("/dev/fpga_push_switch", O_RDWR);

	if (dev<0){
		printf("Device Open Error\n");
		close(dev);
		return ;
	}


	buff_size = sizeof(push_sw_buff);



	

	while(1){

		//LOGV("switch data %d \n",changed);
		
		for(i=0;i<MAX_BUTTON;i++)
			pushed_sw_buff[i] = push_sw_buff[i];

		// Check the fpga switches periodically.

		usleep(50000);

		read(dev, &push_sw_buff, buff_size);

		// Check the two switches in mode 3.


		for(i=0;i<MAX_BUTTON;i++){
			if(pushed_sw_buff[i] == 1 && push_sw_buff[i] == 0){
				changed = i;
				break;
			}
		}
		if(changed != -1)
			break;

	}

	close(dev);

	return changed;
}




