package com.example.labclient;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AS714Activity extends Activity{

	LinearLayout layout;
	
	
	double temperature;
	int humidity;
	double discomfortIndex;
	
	boolean test = false;
	int boundary0 = 68;
	int boundary1 = 75;
	int boundary2 = 80;
	
	Button testBtn;
	TextView temperatureText, humidityText, discomfortText;
	TextView labNameText;
	ReceivingThread mThread;
	
	Handler mHandler = new Handler(){
		public void handleMessage(Message msg){
			if(msg.what == 0){
				temperature = msg.arg1/100.0;
				humidity = msg.arg2;
				
				discomfortIndex = 9/5 * temperature - 0.55 *(1 - humidity/100.0)*(9/5*temperature - 26) + 32;
				
				temperatureText.setText("�ǳ� �µ� : " + temperature);
				humidityText.setText("�ǳ� ���� : "+ humidity);
				discomfortText.setText("�������� : " + Math.round(100*discomfortIndex)/100.0);
				
				if(discomfortIndex < boundary0){//68 54
					layout.setBackgroundColor(Color.GREEN);
					//green
				}
				else if(discomfortIndex < boundary1){//75 57
					layout.setBackgroundColor(Color.CYAN);
					// yellow green
				}
				else if(discomfortIndex < boundary2){// 80
					// orange
					layout.setBackgroundColor(Color.MAGENTA);
				}
				else{
					layout.setBackgroundColor(Color.RED);
					//red
				}
				
			}
		}
	};
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_as714);

		layout = (LinearLayout)findViewById(R.id.as714Container);
		
		temperatureText = (TextView)findViewById(R.id.temperatureText);
		humidityText = (TextView)findViewById(R.id.humidityText);
		discomfortText = (TextView)findViewById(R.id.DiscomfortText);
		labNameText = (TextView)findViewById(R.id.labNameText);
		
		testBtn = (Button)findViewById(R.id.TestBtn);
		
		mThread = new ReceivingThread(mHandler);
		mThread.setDaemon(true);
		mThread.start();
		
		labNameText.setTextColor(Color.DKGRAY);
		
		testBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(test){
					test = false;
					boundary0 = 68;
					boundary1 = 75;
					boundary2 = 80;
					testBtn.setText("Real value >> Testing...");
					
				}
				else{
					test = true;
					boundary0 = 54;
					boundary1 = 57;
					boundary2 = 60;
					testBtn.setText("Testing... >> Real value");
				}
			}
		});
		
	}
	
	@Override
	public void onResume(){
		super.onResume();
	}
	
	@Override
	public void onBackPressed(){
		mThread.isRunning = false;
		mThread.interrupt();
		
		finish();
		super.onBackPressed();
	}
}
