package com.example.labclient;

import java.io.IOException;

import android.os.Handler;
import android.os.Message;

public class ReceivingThread extends Thread{

    Handler mHandler;
    
    int input;
    int temperature;
    int humidity;

    int prevInput = 0;
    int prevHumidity = 0;
    int prevTemperature = 0;
    
    int mode = 0;
    
    boolean isRunning = false;
    
    
    public ReceivingThread(Handler mHandler){
        this.mHandler = mHandler;
    }
    

    
    public void run(){
        
        Message msg;
        
        

        isRunning = true;
        
        while(isRunning){
            try {
                if(MainActivity.getIsConnected()){
                    input = MainActivity.getInputdataStream().read();
                    
                    
                    if(input == 0){
                        mode = input;
                        continue;
                    }
                    else if(input == 1){
                        mode = input;
                        continue;
                    
                    }                    
                    
                    if(mode == 0){
                        double ddata = (double)500 * input / 1024;
                        temperature = (int)(ddata*100);
                        continue;
                    }
                    else if(mode == 1){
                        humidity = input;
                    
                    }
                    
                    msg = Message.obtain();
                    msg.what = 0;
                    
                    
                    msg.arg1 = temperature;
                    msg.arg2 = humidity;
                    
                    
                    mHandler.sendMessage(msg);
                    
                    
                    
                    
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }


    }
}